angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('landing', {
    url: '/page5',
    templateUrl: 'templates/landing.html',
    controller: 'landingCtrl'
  })

  .state('shipping', {
    url: '/page10',
    templateUrl: 'templates/shipping.html',
    controller: 'shippingCtrl'
  })

  .state('iNSURE', {
    url: '/page11',
    templateUrl: 'templates/iNSURE.html',
    controller: 'iNSURECtrl'
  })

  .state('login', {
    url: '/page9',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

$urlRouterProvider.otherwise('')


});